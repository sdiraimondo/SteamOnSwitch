#!/bin/bash

set -e

STEAM_DIR="$HOME/.local/share/Steam"
STEAM_HIDDEN="$HOME/.steam"

mkdir -p "$STEAM_HIDDEN"

# ~/.steam symlinks
ln -snf "$STEAM_DIR/ubuntu12_32" "$STEAM_HIDDEN/bin"
ln -snf "$STEAM_DIR/ubuntu12_32" "$STEAM_HIDDEN/bin32"
ln -snf "$STEAM_DIR/ubuntu12_64" "$STEAM_HIDDEN/bin64"
ln -snf "$STEAM_DIR" "$STEAM_HIDDEN/root"
ln -snf "$STEAM_DIR/linux32" "$STEAM_HIDDEN/sdk32"
ln -snf "$STEAM_DIR/linux64" "$STEAM_HIDDEN/sdk64"
ln -snf "$STEAM_DIR/linuxarm64" "$STEAM_HIDDEN/sdkarm64"
ln -snf "$STEAM_DIR" "$STEAM_HIDDEN/steam"

echo ""
echo "Enlaces simbólicos de Steam ARM64 creados correctamente"
echo ""
