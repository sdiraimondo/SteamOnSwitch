#!/bin/bash

set -e

if [ "$EUID" -ne 0 ]; then
    echo "Este script necesita permisos root"
    echo "Ejecuta: sudo ./install-steam-system-wide.sh"
    exit 1
fi

TARGET_USER=${SUDO_USER:-$(logname)}
USER_HOME=$(eval echo "~$TARGET_USER")

STEAM_DIR="$USER_HOME/.local/share/Steam"
STEAM_BIN="$STEAM_DIR/steamrtarm64/steam"
ICON_PATH="$STEAM_DIR/public/steam_tray.ico"

if [ ! -f "$STEAM_BIN" ]; then
    echo "No se encontró Steam ARM64 en:"
    echo "$STEAM_BIN"
    exit 1
fi

# Wrapper global
cat > /usr/local/bin/steam << EOF
#!/bin/bash
exec "$STEAM_BIN" "\$@"
EOF

chmod +x /usr/local/bin/steam

# Lanzador desktop
mkdir -p /usr/local/share/applications

cat > /usr/local/share/applications/steam.desktop << EOF
[Desktop Entry]
Name=Steam ARM64
Comment=Steam ARM64 Client
Exec=/usr/local/bin/steam
Icon=$ICON_PATH
Terminal=false
Type=Application
Categories=Game;
StartupNotify=true
EOF

chmod 644 /usr/local/share/applications/steam.desktop

update-desktop-database /usr/local/share/applications/ 2>/dev/null || true

echo ""
echo "Steam ARM64 instalado globalmente"
echo ""
echo "Binario: /usr/local/bin/steam"
echo "Lanzador: /usr/local/share/applications/steam.desktop"
echo ""
