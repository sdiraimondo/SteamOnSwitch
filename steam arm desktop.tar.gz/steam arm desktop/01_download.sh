#!/bin/bash

set -e

STEAM_DIR="$HOME/.local/share/Steam"

mkdir -p "$STEAM_DIR"
cd "$STEAM_DIR"

echo "Descargando manifiesto Steam ARM64..."

MANIFEST=$(curl -fsSL "https://client-update.fastly.steamstatic.com/steam_client_publicbeta_linuxarm64" | strings)

TARGET_FILE=$(echo "$MANIFEST" | grep -oP 'bins_linuxarm64_linuxarm64\.zip\.(?!vz\.)[^"]+')

if [ -z "$TARGET_FILE" ]; then
    echo "No se pudo obtener el nombre del paquete ARM64"
    exit 1
fi

DOWNLOAD_URL="https://client-update.steamstatic.com/${TARGET_FILE}"

echo ""
echo "Descargando cliente Steam ARM64..."
echo "$DOWNLOAD_URL"
echo ""

wget -O linuxarm64.zip "$DOWNLOAD_URL"

mkdir -p "$STEAM_DIR/package"
echo publicbeta > "$STEAM_DIR/package/beta"

unzip -o linuxarm64.zip
rm -f linuxarm64.zip

if [ ! -d "$STEAM_DIR/steamrtarm64" ]; then
    echo "No se encontró steamrtarm64 tras extraer el paquete"
    exit 1
fi

chmod +x "$STEAM_DIR/steamrtarm64/steam"

echo ""
echo "Cliente Steam ARM64 instalado correctamente"
echo ""
echo "Binario principal:"
echo "$STEAM_DIR/steamrtarm64/steam"
echo ""
